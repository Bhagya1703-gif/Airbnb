import mongoose from "mongoose";
import { type } from "os";
import { title } from "process";

const PropertySchema = new mongoose.Schema({
    title: {
        type: String,
        required:true,
    },
    desc: {
        type: String,
        required: true,
    },
    img: {
        type: String,
        default:null,
    },
    rating: {
        type: Number,
        default:3.5,

    },
    price: {
        org: {
        type:Number,
        required: false
    },
    mrp: {
        type:Number,
        required:true,
    },
    off: {
        type:Number,
        required:false,
        default:0,
    }
},
},
{timestamps: true}

);

export default mongoose.model("Properties", PropertySchema);