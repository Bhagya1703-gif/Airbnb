import mongoose from "mongoose";
import { type } from "os";

const UserSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true,
    },
    email:{ 
        type:String,
        required: true,
        unquie: true,
    },
    password : {
        type: String,
        required:true,

    },
    favourites: {
        type:[mongoose.Schema.Types.ObjectId],
        ref: "Properties",
        default:[],
    },
},
{timestamps:true}
);
export default mongoose.model("User",UserSchema);
