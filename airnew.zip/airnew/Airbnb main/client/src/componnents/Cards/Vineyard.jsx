import React from "react";
import './Vineyard.css'; // Import the custom CSS file

const Vineyard = () => {
  const features = [
    "Luxurious estate with vineyard views",
    "Private wine tasting tours",
    "Infinity pool with scenic surroundings",
    "5 spacious bedrooms, each with ensuite bathrooms",
    "Fully equipped modern kitchen",
    "Large patio with BBQ area",
    "Free WiFi and workspace for guests",
    "Air conditioning and heating"
  ];

  const amenities = [
    "Free Parking",
    "High-Speed Internet",
    "Pet Friendly",
    "Private Chef available upon request",
    "Hot Tub",
    "Fitness Center",
    "Fireplace"
  ];

  // URL for the vineyard
  const vineyardUrl = "https://www.example.com/vineyard"; // Replace with the actual URL

  return (
    <div className="vineyard-container">
      {/* Header Section */}
      <div className="vineyard-header">
        <h1 className="vineyard-title">Luxurious Vineyard Retreat</h1>
        <p className="vineyard-description">
          Escape to this beautiful vineyard estate located in the heart of wine country. Experience world-class wine and
          relaxation in one unforgettable destination.
        </p>
      </div>

      {/* Image Gallery */}
      <div className="vineyard-gallery">
        <img
          src="https://images.unsplash.com/photo-1506354666786-959d6d497f1a"
          alt="Vineyard view"
          className="vineyard-image"
        />
        <img
          src="https://images.unsplash.com/photo-1519985176271-adb1088fa94c"
          alt="Wine tasting"
          className="vineyard-image"
        />
        <img
          src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750"
          alt="Patio area"
          className="vineyard-image"
        />
        <img
          src="https://images.unsplash.com/photo-1519985176271-adb1088fa94c"
          alt="Wine Cellar"
          className="vineyard-image"
        />
        
      </div>

      {/* Features Section */}
      <div className="vineyard-features">
        <h2 className="vineyard-subtitle">Property Features</h2>
        <ul className="feature-list">
          {features.map((feature, index) => (
            <li key={index} className="feature-item">
              {feature}
            </li>
          ))}
        </ul>
      </div>

      {/* Amenities Section */}
      <div className="vineyard-amenities">
        <h2 className="vineyard-subtitle">Amenities</h2>
        <div className="amenities-list">
          {amenities.map((amenity, index) => (
            <div key={index} className="amenity-item">
              {amenity}
            </div>
          ))}
        </div>
      </div>

      {/* Booking Section */}
      <div className="vineyard-booking">
        <h2 className="vineyard-subtitle">Book Your Stay</h2>
        <div className="booking-info">
          <p className="booking-description">
            Ready to experience a luxurious getaway at our vineyard estate? Book your stay today and enjoy the best that
            wine country has to offer.
          </p>
          <a href={vineyardUrl} target="_blank" rel="noopener noreferrer">
            <button className="booking-button">Check Availability</button>
          </a>
        </div>
      </div>
    </div>
  );
};

export default Vineyard;
